#!/usr/bin/env python
# -*- coding:utf-8 -*-
# author:weishu
# datetime:2022/9/20 5:00 下午
# software: PyCharm
from .image_processor_img2latex import NougatLaTexProcessor
